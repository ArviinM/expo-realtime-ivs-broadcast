require 'json'

package = JSON.parse(File.read(File.join(__dir__, '..', 'package.json')))

Pod::Spec.new do |s|
  s.name           = 'ExpoRealtimeIvsBroadcast'
  s.version        = package['version']
  s.summary        = package['description']
  s.description    = package['description']
  s.license        = package['license']
  s.author         = package['author']
  s.homepage       = package['homepage']
  s.platforms      = {
    :ios => '14.0'
  }
  s.swift_version  = '5.9'
  s.source         = { git: 'https://github.com/ArviinM/expo-realtime-ivs-broadcast' }
  s.static_framework = true

  s.dependency 'ExpoModulesCore'
  s.dependency 'AmazonIVSBroadcast/Stages', '~> 1.36.0'

  # Swift/Objective-C compatibility
  s.pod_target_xcconfig = {
    'DEFINES_MODULE' => 'YES',
  }

  # Include all Swift files in the ios directory
  s.source_files = "**/*.swift"
end
